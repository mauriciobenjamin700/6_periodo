typedef struct Participante;
typedef struct Temporada;
typedef struct Serie;

